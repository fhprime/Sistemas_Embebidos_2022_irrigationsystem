#include "stm32f3xx.h"                  // Device header

int array[5] = {10,20,30,40,50};
int array_procesado[5];
int var_process;
int i = 0;
int main(void){
	for(i = 0; i<=4;i++){
		var_process = array[i];
		var_process = (var_process*5)+100;
		array_procesado[i] = var_process;
	}
	
}
