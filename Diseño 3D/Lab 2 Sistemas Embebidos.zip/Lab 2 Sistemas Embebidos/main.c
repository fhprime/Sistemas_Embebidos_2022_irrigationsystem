#include "stm32f3xx.h"                  // Device header
void USART3_config(void);
void USART3_SENDchar(uint8_t c);
void USART3_SENDSTR(char *string);
void clk_config(void);
void LCD_Command(char command);
void change_lowercase(uint8_t c);
char *st = "HOLA"; 

int main(void){
	clk_config();
	USART3_config();
	LCD_Command(0x01);
	USART3_SENDSTR(st);

	while(1){
	}
}

void LCD_Command(char command){
	USART3_SENDchar(0xFE);   
	USART3_SENDchar(command);   //Limpio la pantalla	
}

void clk_config(void){
	// PLLMUL <- 0x0E (PLL input clock x 16 --> (8 MHz / 2) * 16 = 64 MHz )  
	RCC->CFGR |= 0xE<<18;
	// Flash Latency, two wait states for 48<HCLK<=72 MHz
	FLASH->ACR |= 0x2;
	// PLLON <- 0x1 
  RCC->CR |= RCC_CR_PLLON;
	while (!(RCC->CR & RCC_CR_PLLRDY)) {};	
	// SW<-0x02 (PLL as System Clock), HCLK not divided, PPRE1<-0x4 (APB1 <- HCLK/2), APB2 not divided 
	RCC->CFGR |= 0x402;
	while (!(RCC->CFGR & RCC_CFGR_SWS_PLL)) {};
	SystemCoreClockUpdate();	
}

void USART3_config(void){
	RCC->AHBENR |= RCC_AHBENR_GPIOBEN;					//Habilito reloj a GPIOB
	RCC->APB1ENR |= RCC_APB1ENR_USART3EN;				//Habilito reloj a USART3
	
	GPIOB->MODER |= (0x2<<16)| (0x2<<18);					//Configuro puerto PB8 y PB9 
	GPIOB->AFR[1] |= (0x7<<0); 									//Puerto PB8 RX
	GPIOB->AFR[1] |= (0x7<<4);									//Puerto PB9 TX
	
	USART3->BRR = 3333;         									//(64MHz/2)/9600= 138.8
	USART3->CR1 |= USART_CR1_RE | USART_CR1_TE; //Habilito recepcion y transmision de datos
	USART3->CR1 |= USART_CR1_UE;								//Habilito USART3
	USART3->CR1 |= USART_CR1_RXNEIE;						//Habilito receptor de interrupciones
	NVIC_EnableIRQ(USART3_IRQn);                //Habilito NVIC para interrupcion al USART3
}

void USART3_SENDchar(uint8_t c){
	while(!(USART3->ISR & USART_ISR_TC));
	USART3->TDR = c;
}

void USART3_SENDSTR(char *string){
	while(*string){
		USART3_SENDchar(*string - 'A' + 'a');
		//USART3_SENDchar(*string);
		string++;
	}
}
